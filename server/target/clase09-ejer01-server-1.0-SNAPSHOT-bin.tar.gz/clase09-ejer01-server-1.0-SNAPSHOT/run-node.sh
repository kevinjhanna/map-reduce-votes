#!/bin/bash

java -cp 'lib/jars/*' "com.hazelcast.console.ConsoleApp" $*

